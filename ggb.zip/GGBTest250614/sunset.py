import csv
import time
import random
import requests
from lxml import etree
from time import sleep

print("timeanddate日出日落数据爬取工具")
year = input("请输入年份（如2024）：")
LAT = input("请输入纬度（如32.066286）：")
LON = input("请输入经度（如112.169143）：")
filename = input("请输入保存文件名（如sun_data，不加后缀）：") + ".csv"
write_header = True

# 将时间字符串转换为分钟数的函数
def time_to_minutes(time_str):
    parts = time_str.split(':')
    return int(parts[0]) * 60 + int(parts[1])

for mon in range(1, 13):
    url = f'https://www.timeanddate.com/sun/@{LAT},{LON}?month={mon}&year={year}'
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0",
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.timeanddate.com/',
        'Connection': 'keep-alive'
    }

    # 添加随机延时
    sleep(random.uniform(1, 3))

    response = requests.get(url, headers=headers, timeout=15)
    html = response.text

    parse = etree.HTML(html)

    # 使用更稳定的XPath定位表格
    table = parse.xpath("//table[@id='as-monthsun']")[0]
    all_tr = table.xpath(".//tbody/tr[@data-day]")

    data = []
    for tr in all_tr:
        # 提取日期（th标签内的文本）
        date = tr.xpath("./th/text()")[0].strip()
        
        # 提取日出时间（第一个td的第一个文本节点）
        sunrise = tr.xpath("./td[1]/text()")[0].split()[0].strip()
        
        # 提取日落时间（第二个td的第一个文本节点）
        sunset = tr.xpath("./td[2]/text()")[0].split()[0].strip()
        
        # 计算日出分钟数
        sr_min = time_to_minutes(sunrise)
        # 计算日落分钟数
        ss_min = time_to_minutes(sunset)
        # 计算白昼时长（分钟）
        daytime_min = ss_min - sr_min
        
        row = {
            'Date': f"{year}-{mon}-{date}",  # 构造完整日期
            'Sunrise': sunrise,
            'Sunset': sunset,
            'SRmin': sr_min,
            'SSmin': ss_min,
            'Daytime': daytime_min
        }
        data.append(row)
        print(row)

    # 保存到CSV
    with open(filename, 'a', newline='', encoding='utf-8') as f:
        fieldnames = ['Date', 'Sunrise', 'Sunset', 'SRmin', 'SSmin', 'Daytime']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
            write_header = False
        writer.writerows(data)
